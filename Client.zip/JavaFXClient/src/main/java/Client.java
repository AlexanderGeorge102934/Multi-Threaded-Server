import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;

// Define a class named Client that extends the Thread class.
public class Client extends Thread {

    // Fields to manage communication with the server.
    private Socket socketClient;          // The client's socket.
    private ObjectOutputStream out;       // Output stream for sending objects.
    private ObjectInputStream in;         // Input stream for receiving objects.
    private GameInfo gameInfo;            // Stores information related to the game.

    // Callback function to handle received data.
    private Consumer<Serializable> callback;

    // Constructor to initialize the Client object with a callback function.
    Client(Consumer<Serializable> call) {
        callback = call;
    }

    // The main execution thread of the client.
    public void run() {
        try {
            // Establish a connection to the server at address "127.0.0.1" and port 5555.
            socketClient = new Socket("127.0.0.1", 5555);
            out = new ObjectOutputStream(socketClient.getOutputStream());
            in = new ObjectInputStream(socketClient.getInputStream());
            
            // Enable TCP no-delay to reduce latency.
            socketClient.setTcpNoDelay(true);
        } catch (Exception e) {
            // Handle any exceptions that may occur during connection setup.
            // Note: Proper error handling should be implemented here.
        }

        while (true) {
            try {
                // Read an incoming GameInfo object from the server.
                GameInfo message = (GameInfo) in.readObject();
                // Pass the received message to the callback function for handling.
                callback.accept(message);
            } catch (Exception e) {
                // Handle any exceptions that may occur during message reception.
                System.out.println("Error " + e.getMessage());
            }
        }
    }

    // Method for sending a GameInfo object to the server.
    public void send(GameInfo gameInfo) {
        try {
            out.writeObject(gameInfo);
        } catch (IOException e) {
            // Handle any exceptions that may occur during object sending.
            e.printStackTrace();
        }
    }
}
