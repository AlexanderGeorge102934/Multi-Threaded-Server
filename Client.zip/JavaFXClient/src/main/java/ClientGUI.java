// Importing necessary JavaFX and networking libraries
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

// Main class for the Client GUI, extending JavaFX Application
public class ClientGUI extends Application {
    // Network components for client-server communication
    private Socket socketClient;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    // JavaFX components for the user interface
    private Stage primaryStage;
    private VBox connectionLayout, categoryLayout, gameLayout;
    private TextField ipInput, portInput, guessInput;
    private Button connectButton, guessButton, playAgainButton, quitButton;
    private Label gameStatusLabel, guessesLeftLabel;
    private String currentCategory;
    private int remainingGuesses;
    private Set<String> wonCategories = new HashSet<>();
    private Set<String> totalCategories = new HashSet<>(Arrays.asList("cities", "fruits", "colors"));
    private GameInfo gameInfo;

    // Method called at the start of the JavaFX application
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Word Guessing Game - Client");

        // Initialize game information
        if (gameInfo == null) {
            gameInfo = new GameInfo();
        }

        // Setting up the different interfaces for the application
        createConnectionInterface();
        createCategoryInterface();
        createGameInterface();

        // Configuring the initial scene of the application
        Scene scene = new Scene(connectionLayout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();

        // Handling the closure of the application window
        primaryStage.setOnCloseRequest(e -> {
            quitGame();
        });
    }

    // Method to create the interface for server connection
    private void createConnectionInterface() {
        // Setting up layout and components for connection interface
        connectionLayout = new VBox(10);
        connectionLayout.setAlignment(Pos.CENTER);
        connectionLayout.setPadding(new Insets(20));

        // Creating and configuring UI components for connection
        Label connectionLabel = new Label("Server Connection");
        connectionLabel.setFont(new Font("Arial", 18));
        ipInput = new TextField("127.0.0.1");
        portInput = new TextField("5555");
        connectButton = new Button("Connect");
        connectButton.setOnAction(e -> connectToServer());

        // Adding components to the connection layout
        connectionLayout.getChildren().addAll(connectionLabel, new Label("Server IP:"), ipInput, new Label("Port:"), portInput, connectButton);
    }

    // Method to create the category selection interface
    private void createCategoryInterface() {
        // Setting up layout and components for category selection
        categoryLayout = new VBox(10);
        categoryLayout.setAlignment(Pos.CENTER);
        categoryLayout.setPadding(new Insets(20));
        categoryLayout.setVisible(false);

        // Displaying game rules
        Label rulesLabel = new Label("Game Rules:\n" +
                                     "- You get 6 guesses to guess a word from one of the three categories.\n" +
                                     "- You get 3 attempts for each category. Using all 3 attempts on any category results in an automatic game over.\n" +
                                     "- If you guess a word within 6 attempts, you win that category and cannot choose from it again.\n" +
                                     "- To win the game, complete all 3 categories.");
        rulesLabel.setFont(new Font("Arial", 14));
        rulesLabel.setWrapText(true);

        // Creating buttons for category selection
        Label categoryLabel = new Label("Choose a Category");
        categoryLabel.setFont(new Font("Arial", 18));
        HBox categoryButtons = new HBox(10);
        categoryButtons.setAlignment(Pos.CENTER);

        // Loop to create buttons for each category
        String[] categories = {"cities", "fruits", "colors"};
        for (String category : categories) {
            Button categoryButton = new Button(category);
            categoryButton.setOnAction(e -> chooseCategory(category));
            if (wonCategories.contains(category)) {
                categoryButton.setDisable(true);
            }
            categoryButtons.getChildren().add(categoryButton);
        }

        // Adding components to the category layout
        categoryLayout.getChildren().addAll(rulesLabel, categoryLabel, categoryButtons);
    }

    // Method to create the game interface
    private void createGameInterface() {
        // Setting up layout and components for the game interface
        gameLayout = new VBox(10);
        gameLayout.setAlignment(Pos.CENTER);
        gameLayout.setPadding(new Insets(20));
        gameLayout.setVisible(false);

        // Configuring UI components for gameplay
        gameStatusLabel = new Label();
        guessesLeftLabel = new Label("Guesses left: 6");
        guessInput = new TextField();
        guessButton = new Button("Guess");
        guessButton.setOnAction(e -> sendGuess());
        playAgainButton = new Button("Play Again");
        playAgainButton.setVisible(false);
        playAgainButton.setOnAction(e -> {
            String message = "Play Again";
            sendMessageToServer(message);
        });
        quitButton = new Button("Quit");
        quitButton.setOnAction(e -> quitGame());

        // Adding components to the game layout
        gameLayout.getChildren().addAll(gameStatusLabel, guessesLeftLabel, guessInput, guessButton, playAgainButton, quitButton);
    }

    // Method to handle server connection
    private void connectToServer() {
        try {
            // Attempting to connect to the server
            String ip = ipInput.getText().trim();
            int port = Integer.parseInt(portInput.getText().trim());
            socketClient = new Socket(ip, port);
            out = new ObjectOutputStream(socketClient.getOutputStream());
            in = new ObjectInputStream(socketClient.getInputStream());
            showCategoryInterface();
            new Thread(this::listenToServer).start();
        } catch (Exception e) {
            // Handling connection errors
            Alert alert = new Alert(Alert.AlertType.ERROR, "Unable to connect to server: " + e.getMessage());
            alert.showAndWait();
        }
    }

    // Method to handle category selection
    private void chooseCategory(String category) {
        try {
            // Sending category choice to the server
            gameInfo.setMessage(category);
            out.reset();
            out.writeUnshared(gameInfo);
            out.flush();
            showGameInterface("Category: " + category);
        } catch (Exception e) {
            // Handling errors in category selection
            e.printStackTrace();
            gameStatusLabel.setText("Error selecting category: " + e.getMessage());
        }
    }

    // Method to handle sending guesses to the server
    private void sendGuess() {
        try {
            // Sending guess to the server
            String guess = guessInput.getText().trim();
            gameInfo.setMessage(guess);
            out.reset();
            out.writeUnshared(gameInfo);
            out.flush();
            guessInput.clear();
        } catch (Exception e) {
            // Handling errors in sending guess
            gameStatusLabel.setText("Error sending guess: " + e.getMessage());
        }
    }

    // Method to send messages to the server
    private void sendMessageToServer(String message) {
        try {
            // Sending a generic message to the server
            gameInfo.setMessage(message);
            out.writeObject(gameInfo);
            out.flush();
        } catch (Exception e) {
            // Handling exceptions in message sending
            e.printStackTrace();
        }
    }

    // Method to listen to server messages
    private void listenToServer() {
        try {
            // Continuously listening for messages from the server
            while (true) {
                GameInfo response = (GameInfo) in.readObject();
                Platform.runLater(() -> processServerResponse(response.getMessage()));
            }
        } catch (Exception e) {
            // Handling connection closure
            Platform.runLater(() -> gameStatusLabel.setText("Connection closed."));
        }
    }
    
    //Proccesses the type of action to do based on what the server gives as a response 
    public void processServerResponse(String response) {
    	
        if (response.startsWith("Category:")) {
            // Extract the category name
            String category = response.substring("Category: ".length(), response.indexOf(". Word has"));

            // Extract the number of letters in the word
            String afterCategory = response.substring(response.indexOf(". Word has ") + ". Word has ".length());
            int lettersInWord = Integer.parseInt(afterCategory.substring(0, afterCategory.indexOf(" letters")));

            // Extract the number of remaining guesses
            String guessesPart = afterCategory.substring(afterCategory.indexOf("Remaining guesses: ") + "Remaining guesses: ".length());
            remainingGuesses = Integer.parseInt(guessesPart.trim());

            updateGameStatus(category, lettersInWord);
        }else if (response.startsWith("Wrong guess:")) {
            // Extract and update the number of remaining guesses
        	
        	gameStatusLabel.setText(response);
            try {
                String guessesStr = response.replaceAll("[^0-9]", "");
                if (!guessesStr.isEmpty()) {
                    remainingGuesses = Integer.parseInt(guessesStr);
                    	
                    updateGameStatus(currentCategory);
                } else {
                    // Handle the case where no number is found
                    System.out.println("No numeric value found for remaining guesses in the response: " + response);
                }
            } catch (NumberFormatException e) {
                System.out.println("Error parsing remaining guesses from the response: " + response);
            }
        } 
        else if(response.startsWith("Good guess:")){
        	gameStatusLabel.setText(response);	
        }
        
        else if (response.contains("guessed correctly!")) {
            gameStatusLabel.setText(response);
            wonCategories.add(currentCategory); // Add the category to won categories
            showEndGameOptions();
            updateCategoryButtons(); // Update category buttons to reflect the win
            checkForGameCompletion(); // Check if the game is completed
        }
        else if (response.contains("Please choose a new category")){
            // Reset the game interface for the next round
            restartGame();
            
            // Show the category selection interface
            showCategoryInterface();
        	
        }
        else if (response.contains("Sorry but you have guessed incorrectly 6 times")) {
        	gameStatusLabel.setText(response);
        	showEndGameOptions();
        	
        	
        }
        else if (response.contains("Game Over.")) {
            // Handle game end scenarios
            gameStatusLabel.setText(response);
            disableAllCategoryButtons();  // Disable all category buttons
            showEndGameOptionsOnlyQuit(); // Show only the Quit button
        } 
        else {
            // Handle any other type of response
            gameStatusLabel.setText(response);
        }
    }


    //Updates game status
    public void updateGameStatus(String category) {
        currentCategory = category;
        guessesLeftLabel.setText("Guesses left: " + remainingGuesses);
    }
    //Updates game status
    public void updateGameStatus(String category, int lettersInWord) {
        currentCategory = category;
        gameStatusLabel.setText("Category: " + category + ". Word has " + lettersInWord + " letters.");
        guessesLeftLabel.setText("Guesses left: " + remainingGuesses); // Initially set to 6 in createGameInterface
    }
    
    //Updates hiding the category once completed 
    public void updateCategoryButtons() {
        for (Node node : categoryLayout.getChildren()) {
            if (node instanceof HBox) {
                HBox hbox = (HBox) node;
                for (Node buttonNode : hbox.getChildren()) {
                    if (buttonNode instanceof Button) {
                        Button button = (Button) buttonNode;
                        if (wonCategories.contains(button.getText())) {
                            button.setDisable(true); // Disable the button if the category is already won
                        }
                    }
                }
            }
        }
    }
    
    //Disables all category buttons from being able to be clicked 
    public void disableAllCategoryButtons() {
        for (Node node : categoryLayout.getChildren()) {
            if (node instanceof HBox) {
                HBox hbox = (HBox) node;
                for (Node buttonNode : hbox.getChildren()) {
                    if (buttonNode instanceof Button) {
                        buttonNode.setDisable(true); // Disable all buttons
                    }
                }
            }
        }
    }

    //Shows only quit button when game ends  
    public void showEndGameOptionsOnlyQuit() {
        guessButton.setDisable(true);
        playAgainButton.setVisible(false);
        quitButton.setVisible(true);
    }
    
    
    //Checks to see if game has been completed or not 
    private void checkForGameCompletion() {
        if (wonCategories.equals(totalCategories)) {
        	sendMessageToServer("Client has completed all 3 categories");
            gameStatusLabel.setText("Congratulations! You've completed all categories. Game Over!");
            // Disable all gameplay buttons and show only the quit button
            guessButton.setDisable(true);
            playAgainButton.setDisable(true);
            quitButton.setVisible(true);
        }
    }

    //Show options for playing again or quitting
    private void showEndGameOptions() {
        guessButton.setDisable(true);
        playAgainButton.setVisible(true);
        quitButton.setVisible(true);
    }

    //Restarts the game 
    public void restartGame() {
        guessButton.setDisable(false);
        playAgainButton.setVisible(false);
        quitButton.setVisible(false);
        remainingGuesses = 6; // Reset remaining guesses to 6
        currentCategory = null; // Reset the current category
        gameStatusLabel.setText(""); // Clear the game status label
        showCategoryInterface();
        guessesLeftLabel.setText("Guesses left: " + remainingGuesses); // Update the label
    }

    //Exits out of game 
    private void quitGame() {
        closeConnection();
        primaryStage.close();
    }

    //Shows categories 
    private void showCategoryInterface() {
        connectionLayout.setVisible(false);
        gameLayout.setVisible(false);
        categoryLayout.setVisible(true);
        primaryStage.getScene().setRoot(categoryLayout);
    }

    //Shows game 
    private void showGameInterface(String statusMessage) {
        gameStatusLabel.setText(statusMessage);
        categoryLayout.setVisible(false);
        gameLayout.setVisible(true);
        primaryStage.getScene().setRoot(gameLayout);
    }

    //Closes connection to server 
    private void closeConnection() {
        try {
            if (socketClient != null) socketClient.close();
            if (out != null) out.close();
            if (in != null) in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Main method to launch the JavaFX application
    public static void main(String[] args) {
        launch(args);
    }
    

}