import java.io.Serializable;

// Define a class named GameInfo that implements the Serializable interface.
public class GameInfo implements Serializable {

    // A unique identifier for serialization purposes.
    private static final long serialVersionUID = 1L;

    // Fields to store information about the game.
    private String currentCategory;  // Stores the current category of the game.
    private String currentWord;      // Stores the current word being guessed.
    private int remainingGuesses;    // Stores the number of remaining guesses.
    private String gameStatus;       // Stores the status of the game (e.g., "ongoing" or "won").

    private String message;          // Stores an additional message related to the game.

    // Constructor to initialize the GameInfo object.
    public GameInfo() {
        // Initialize the message to an empty string.
        this.message = "";
        
        // Initialize the remainingGuesses to 6 (default value).
        remainingGuesses = 6;
        
        // Initialize the currentCategory and currentWord to empty strings.
        currentCategory = "";
        currentWord = "";
    }

    // Getter method for retrieving the current category.
    public String getCurrentCategory() {
        return currentCategory;
    }

    // Setter method for updating the current category.
    public void setCurrentCategory(String currentCategory) {
        this.currentCategory = currentCategory;
    }

    // Getter method for retrieving the current word.
    public String getCurrentWord() {
        return currentWord;
    }

    // Setter method for updating the current word.
    public void setCurrentWord(String currentWord) {
        this.currentWord = currentWord;
    }

    // Getter method for retrieving the remaining number of guesses.
    public int getRemainingGuesses() {
        return remainingGuesses;
    }

    // Setter method for updating the remaining number of guesses.
    public void setRemainingGuesses(int remainingGuesses) {
        this.remainingGuesses = remainingGuesses;
    }

    // Getter method for retrieving the game status.
    public String getGameStatus() {
        return gameStatus;
    }

    // Setter method for updating the game status.
    public void setGameStatus(String gameStatus) {
        this.gameStatus = gameStatus;
    }

    // Getter method for retrieving an additional message related to the game.
    public String getMessage() {
        return message;
    }

    // Setter method for updating the additional message.
    public void setMessage(String message) {
        this.message = message;
    }
}
