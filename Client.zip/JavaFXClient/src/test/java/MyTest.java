import static org.junit.jupiter.api.Assertions.*;

import java.net.Socket;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest {

    
	private GameInfo gameInfo;

    @Test
    public void testDefaultConstructorValues() {
    	gameInfo = new GameInfo();
        assertEquals("", gameInfo.getCurrentCategory());
        assertEquals("", gameInfo.getCurrentWord());
        assertEquals(6, gameInfo.getRemainingGuesses());
        assertNull(gameInfo.getGameStatus());
        assertEquals("", gameInfo.getMessage());
    }
    
    @Test
    public void testDefaultConstructorValues2() {
    	gameInfo = new GameInfo();
        assertNotEquals("hello", gameInfo.getCurrentCategory());
        assertNotEquals("hello", gameInfo.getCurrentWord());
        assertNotEquals(7, gameInfo.getRemainingGuesses());
        assertNull(gameInfo.getGameStatus());
        assertNotEquals("hello", gameInfo.getMessage());
    }

    @Test
    public void testSetAndGetCategory() {
    	gameInfo = new GameInfo();
        gameInfo.setCurrentCategory("fruits");
        assertEquals("fruits", gameInfo.getCurrentCategory());
    }

    @Test
    public void testSetAndGetWord() {
    	gameInfo = new GameInfo();
        gameInfo.setCurrentWord("apple");
        assertEquals("apple", gameInfo.getCurrentWord());
    }

    @Test
    public void testSetAndGetRemainingGuesses() {
    	gameInfo = new GameInfo();
        gameInfo.setRemainingGuesses(5);
        assertEquals(5, gameInfo.getRemainingGuesses());
    }

    @Test
    public void testSetAndGetGameStatus() {
    	gameInfo = new GameInfo();
        gameInfo.setGameStatus("In Progress");
        assertEquals("In Progress", gameInfo.getGameStatus());
    }

    @Test
    public void testSetAndGetMessage() {
    	gameInfo = new GameInfo();
        gameInfo.setMessage("Welcome");
        assertEquals("Welcome", gameInfo.getMessage());
    }

    @Test
    public void testRemainingGuessesBoundaryPositive() {
    	gameInfo = new GameInfo();
        gameInfo.setRemainingGuesses(10);
        assertEquals(10, gameInfo.getRemainingGuesses());
    }


    @Test
    public void testGameStatusForNull() {
    	gameInfo = new GameInfo();
        gameInfo.setGameStatus(null);
        assertNull(gameInfo.getGameStatus());
    }

    @Test
    public void testMessageForNull() {
    	gameInfo = new GameInfo();
        gameInfo.setMessage(null);
        assertNull(gameInfo.getMessage());
    }
    
    
    


}
