import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class GuiServer extends Application {
    private Server server; // Instance of your Server class

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Word Guessing Game - Server");

        // Styling constants
        final Font labelFont = Font.font("Arial", 16);
        final Insets padding = new Insets(10, 10, 10, 10);

        // Title
        Text title = new Text("Game Server Control Panel");
        title.setFont(Font.font("Arial", 20));

        // Port number input
        Label portLabel = new Label("Enter Port Number:");
        portLabel.setFont(labelFont);
        TextField portInput = new TextField();
        Button startButton = new Button("Start Server");
        HBox portBox = new HBox(10, portLabel, portInput, startButton);
        portBox.setAlignment(Pos.CENTER);
        portBox.setPadding(padding);

        // Server log area
        TextArea serverLog = new TextArea();
        serverLog.setEditable(false);
        serverLog.setPrefHeight(200);

        VBox layout = new VBox(15, title, portBox, serverLog);
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setPadding(padding);

        // Styling the layout background
        layout.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));

        // Start server button action
        startButton.setOnAction(e -> {
            try {
                int port = Integer.parseInt(portInput.getText().trim());
                server = new Server(message -> Platform.runLater(() -> serverLog.appendText(message + "\n")), port);
                portInput.setDisable(true);
                startButton.setDisable(true);
            } catch (NumberFormatException ex) {
                serverLog.appendText("Invalid port number: " + portInput.getText() + "\n");
            }
        });

        Scene scene = new Scene(layout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @Override
    public void stop() {
        if (server != null && server.server != null) {
            server.server.interrupt(); // Stop the server thread
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
