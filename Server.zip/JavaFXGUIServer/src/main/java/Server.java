import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.scene.control.ListView;


public class Server{

	int count = 1;	
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	TheServer server;
	int portNum = 0;
	private Consumer<Serializable> callback;
	
	//Categories with their words in them
    String[] cities = {
            "Paris", "Tokyo", "Delhi", "Cairo", "Milan", "Oslo", "Lyon", "Dubai", "Perth", "Leeds",
            "Miami", "Vegas", "Salem", "Busan", "Dover", "Rome", "Lagos", "Osaka", "Tampa", "Hanoi",
            "Kyoto", "Dhaka"
        };
    String[] fruits = {
            "Apple", "Pear", "Grape", "Lemon", "Mango", "Melon", "Berry", "Peach", "Plum", "Lime",
            "Kiwi", "Fig", "Date", "Guava", "Papya", "Lychee", "Cherry", "Olive", "Banana", "Grape", 
            "Pome", "Quince"
        };
    String[] colors = {
            "Red", "Blue", "Green", "Black", "White", "Pink", "Cyan", "Beige", "Lime", "Navy",
            "Teal", "Olive", "Coral", "Khaki", "Taupe", "Rust", "Ivory", "Plum", "Mauve", "Cream",
            "Amber", "Slate"
        };
    
    //Constructor for the Server class.
    Server(Consumer<Serializable> call, int port) {
        // Set the port number for the server.
        this.portNum = port;

        // Set the callback function to handle received data.
        callback = call;

        // Create and start a new server thread.
        server = new TheServer();
        server.start();
    }

    //Server extends Thread
	public class TheServer extends Thread{
		
		public void run() {
		
			try(ServerSocket mysocket = new ServerSocket(portNum);){
		    System.out.println("Server is waiting for a client!");
		    while(true) {
				ClientThread c = new ClientThread(mysocket.accept(), count);
				callback.accept("client has connected to server: " + "client #" + count);
				clients.add(c);
				c.start();
				count++;
				
			    }
			}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			}//end of while
		}
	
		//Client Thread extends Thread
		class ClientThread extends Thread{
		    // Game-specific attributes
		    private String currentCategory;
		    private String currentWord;
		    private StringBuilder wordProgress;
		    private int remainingGuesses = 6;
		    private boolean gameActive = true;
		    private int categoryCityAttempts =3;
		    private int categoryFruitsAttempts =3;
		    private int categoryColorsAttempts =3;
		    GameInfo gameInfo;

		    //Handles client-server messages
			Socket connection;
			int count;
			ObjectInputStream in;
			ObjectOutputStream out;
			
			
			ClientThread(Socket s, int count){
				this.connection = s;
				this.count = count;	
				this.gameInfo = new GameInfo(); // Initialize gameInfo here
				
			}
			
			public void updateClients(String message) {
				for(int i = 0; i < clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
					 t.out.writeObject(message);
					}
					catch(Exception e) {}
				}
			}
			
			//The main execution method for a client thread. It manages communication with the connected client.
			public void run() {
			    try {
			        // Initialize input and output streams for communication with the client.
			        in = new ObjectInputStream(connection.getInputStream());
			        out = new ObjectOutputStream(connection.getOutputStream());

			        // Enable TCP no-delay to reduce latency.
			        connection.setTcpNoDelay(true);
			    } catch (Exception e) {
			        // Handle exceptions if streams cannot be opened.
			        System.out.println("Streams not open");
			    }

			    // Continuous loop to handle communication with the client.
			    while (true) {
			        try {
			            // Read an incoming GameInfo object from the client.
			            GameInfo received = (GameInfo) in.readObject();

			            // Check if the received object is an instance of GameInfo.
			            if (received instanceof GameInfo) {
			                // Extract the message from the received GameInfo object.
			                String message = received.getMessage();
			                
			                // Process the received message from the client.
			                processClientMessage(message);
			            }
			        } catch (Exception e) {
			            // Handle exceptions when there is an issue with the client connection.
			            // Notify that the client has left the server and remove the client from the list.
			            callback.accept("Client #" + count + " has left the server!");
			            clients.remove(this);
			            break;
			        }
			    }
			} // end of run

			
			public void processClientMessage(String message) {
			    // If the message is one of the categories, we should start the category selection process
			    if (message.equalsIgnoreCase("cities") || message.equalsIgnoreCase("fruits") || message.equalsIgnoreCase("colors")) {
			    	callback.accept("Client #"+count+" chose category " +message);
			        selectCategory(message);
			    } else if (message.length() == 1) { 
			        // Check if the single character is a letter
			        char guess = message.charAt(0);
			        if (Character.isLetter(guess)) {
			        	callback.accept("Client #"+count+" chose letter " +guess);
			            // Assuming a single character is a guess
			            processGuess(guess);
			        } else {
			            // If the single character is not a letter, send an invalid input message
			        	callback.accept("Client #"+count+" inputted an invalid input");
			            sendMessageToClient("Invalid input: '" + message + "' is not a letter. Please guess a letter.", gameInfo);
			        }
			    } else if (message.contains("Play Again")) {
			    	//Client chooses to play again
			    	callback.accept("Client #"+count+" chose to play again");
			        resetGame();
			        sendMessageToClient("Please choose a new category to start the game.", gameInfo);
			    } 
			    else if(message.contains("Client has completed all 3 categories")){
			    	//Client finished all three categories 
			    	callback.accept("Client #"+count+" won the game");
			    	endGame(true);
			    }
			    else {
			        // If the message is not recognized, send an error or instructions
			    	callback.accept("Client #"+count+" inputted an invalid input");
			        sendMessageToClient("Invalid input. Please try again.",gameInfo);
			    }
			}

			//Category gets assigned to currentCategory 
		    public void selectCategory(String category) {
		        String[] categoryWords;
		        switch (category.toLowerCase()) {
		            case "cities":
		                categoryWords = cities;
		                break;
		            case "fruits":
		                categoryWords = fruits;
		                break;
		            case "colors":
		                categoryWords = colors;
		                break;
		            default:
		                sendMessageToClient("Invalid category", gameInfo);
		                return;
		        }

		        currentCategory = category;
		        Random rand = new Random();
		        currentWord = categoryWords[rand.nextInt(categoryWords.length)].toUpperCase();//Finds random word in category 
		        wordProgress = new StringBuilder("_".repeat(currentWord.length()));
		        remainingGuesses = 6;
		        
		        
		        callback.accept("Server has sent Client #"+count+" the word " + currentWord + " to guess");
		        sendMessageToClient("Category: " + category + ". Word has " + currentWord.length() + " letters. Remaining guesses: " + remainingGuesses, gameInfo);
		    }

		    public void processGuess(char guess) {
		    	//Client hasn't chosen a word yet 
		        if (currentWord == null || currentCategory == null) {
		        	callback.accept("Server has sent Client #"+count+" to choose a category first");
		            sendMessageToClient("Please choose a category first.", gameInfo);
		            return;
		        }

		        // Convert the guessed letter to uppercase to match the word's casing
		        guess = Character.toUpperCase(guess);

		        // Check if the guessed letter is in the word
		        boolean letterFound = false;
		        for (int i = 0; i < currentWord.length(); i++) {
		            if (currentWord.charAt(i) == guess) {
		                // Update the wordProgress with the correct letter
		                wordProgress.setCharAt(i, guess);
		                letterFound = true;
		            }
		        }

		        if (letterFound) {
		            // Guessed letter is in the word
		        	callback.accept("Server has told Client #"+count+" they have chosen the correct letter "+ guess);
		            sendMessageToClient("Good guess: " + wordProgress.toString(), gameInfo);
		            if (wordProgress.toString().equals(currentWord)) {
		            	callback.accept("Client #"+count+" has correctly chosen the guessed the word " + currentWord + ", the category " + currentCategory + " is now completed");
		                sendMessageToClient("Word guessed correctly! Choose next category.", gameInfo);
		            }
		        } else {
		            // Guessed letter is not in the word
		            remainingGuesses--;
		            callback.accept("Server has told Client #"+count+" they have chosen the incorrect letter "+ guess);
		            sendMessageToClient("Wrong guess: " + wordProgress.toString() + " Remaining guesses: " + remainingGuesses, gameInfo);
		            if (remainingGuesses <= 0) {
		            	
		            	if (currentCategory.equals("cities")) {
		            		categoryCityAttempts--;
		            		if(categoryCityAttempts<=0) {
		            			callback.accept("Server has told Client #"+count+" they lost the game ");
		            			sendMessageToClient("Sorry but you have lost again on your final attempt. Game Over.", gameInfo);
		            			endGame(false);
		            		}
		            		else {
		            			callback.accept("Server has told Client #"+count+" they guessed incorrectly 6 times and they must try again ");
		            			sendMessageToClient("Sorry but you have guessed incorrectly 6 times. Please try choosing another word from this category or another.", gameInfo);
		    			        resetGame();
		            		}
		            		
		            		
		            	}
		            	else if(currentCategory.equals("fruits")) {
		            		categoryFruitsAttempts--;
		            		if(categoryFruitsAttempts<=0) {
		            			callback.accept("Server has told Client #"+count+" they lost the game ");
		            			sendMessageToClient("Sorry but you have lost again on your final attempt. Game Over.", gameInfo);
		            			endGame(false);
		            		}
		            		else {
		            			callback.accept("Server has told Client #"+count+" they guessed incorrectly 6 times and they must try again ");
		            			sendMessageToClient("Sorry but you have guessed incorrectly 6 times. Please try choosing another word from this category or another.", gameInfo);
		            			
		            			resetGame();
		            		}
		            		
		            	}
		            	else if(currentCategory.equals("colors")) {
		            		categoryColorsAttempts--;
		            		if(categoryColorsAttempts<=0) {
		            			callback.accept("Server has told Client #"+count+" they lost the game ");
		            			sendMessageToClient("Sorry but you have lost again on your final attempt. Game Over.", gameInfo);
		            			endGame(false);
		            		}
		            		else {
		            			callback.accept("Server has told Client #"+count+" they guessed incorrectly 6 times and they must try again ");
		            			sendMessageToClient("Sorry but you have guessed incorrectly 6 times. Please try choosing another word from this category or another.", gameInfo);
		            			
		            			resetGame();
		            		}
		            	}
		            }
		        }
		    }

		    //Resets the game
		    private void resetGame() {
		        currentCategory = null;
		        currentWord = null;
		        wordProgress = null;
		        remainingGuesses = 6;
		        gameActive = true; // Set this to true to indicate the game can continue.
		    }
		    
		    //Resets message to client 
		    private void sendMessageToClient(String message, GameInfo gameInfo) {
		        try {
		            if (this.gameInfo == null) {
		                this.gameInfo = new GameInfo();
		            }
		            this.gameInfo.setMessage(message);
		            
		            
		            out.reset(); //Reset the stream to forget about the state of previously sent objects
		            out.writeObject(this.gameInfo);
		            out.flush();
		        } catch (Exception e) {
		            System.out.println("Error sending message to client: " + e.getMessage());
		        }
		    }

		    //Ends the game 
		    private void endGame(boolean won) {
		        if(won) {
		            sendMessageToClient("Congratulations! You've won the game.", gameInfo);
		        } else {
		            sendMessageToClient("Out of attempts. Game Over.", gameInfo);
		        }
		        resetGame(); // Reset the game after it ends.
		    }
			
			
			
		}//end of client thread

		//Getter for port num
		public Integer getPortNum() {
			
			return this.portNum;
		}
}