import static org.junit.jupiter.api.Assertions.*;

import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest {


}
